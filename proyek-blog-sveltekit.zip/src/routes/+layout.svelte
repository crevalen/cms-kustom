<script lang="ts">
	// Baris ini akan memuat file CSS utama kita untuk seluruh aplikasi
	import '../app.css';
</script>

<slot />