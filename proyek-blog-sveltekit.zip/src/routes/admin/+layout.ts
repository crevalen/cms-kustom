// src/routes/admin/+layout.ts
export const ssr = false;