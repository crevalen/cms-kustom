declare module 'text-readability';
